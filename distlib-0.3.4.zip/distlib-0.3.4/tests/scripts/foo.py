def main():
    print('Hello from foo')

def other_main():
    print('Hello again from foo')

