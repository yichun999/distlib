# -*- coding: utf-8 -*-
from choxie.chocolate import Chocolate

class Truffle(Chocolate):
    """A truffle."""
