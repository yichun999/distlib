This distribution is used to test distlib.

